Ho dovuto cambiare la velocit� base da 1 a 0.1 perch� altrimenti sarebbe stato troppo veloce, di conseguenza la velocit� di caduta aumenta di 0.05.

Nel documento non si parlava di alcun punteggio, l'ho implementato altrimenti il gioco non sarebbe stato molto divertente.

Non � specificato cosa succede quando un oggetto non viene preso, quindi ho lasciato che non succede nulla, sarebbe bene specificare.

Si parte sempre come un quadrato bianco, non in modo casuale. Errore mio.